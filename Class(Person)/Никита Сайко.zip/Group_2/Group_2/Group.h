#pragma once

#include "Person.h"

class Group
{
	Person** People;
	size_t MaxLength;
	size_t CurrentLength;

public:

	Group();
	Group(size_t max_length);
	Group(const Group& source);
	~Group();

	void Add(Person* person);
	void Print();
	bool Remove(unsigned index);
	bool Remove(Person* person);
	bool Save(const char* file_name);
	bool Load(const char* file_name);

	bool operator == (const Group& Group2);
	Group& operator = (const Group& source);
	Group operator+ (Person* person);
	Group operator- (Person* person);
	Group operator+= (Person* person);
	Group operator-= (Person* person);
	Group operator+ (const Group& source);
};