#pragma once
class Person
{
	char* FirstName;
	char* LastName;
	unsigned Age;

public:

	Person();
	Person(const char* first_name, const char* last_name, unsigned age);
	Person(Person& source);
	~Person();

	void SetAll(const char* first_name, const char* last_name, unsigned age);
	char* GetFirstName();
	char* GetLastName();
	unsigned* GetAge();

	void Print();

	Person operator= (const Person& source);
	bool operator!= (const Person& source);
	bool operator== (const Person& source);
};