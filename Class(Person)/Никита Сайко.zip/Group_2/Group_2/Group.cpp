#define _CRT_SECURE_NO_WARNINGS

#include <iostream>
#include "Person.h"
#include "Group.h"

using namespace std;


Group::Group()
{
	cout << "Constr group" << endl;

	MaxLength = 10;
	CurrentLength = 0;
	People = new Person * [MaxLength];
}


Group::Group(size_t max_length)
{
	cout << "Constr with params group" << endl;

	MaxLength = max_length;
	CurrentLength = 0;
	People = new Person * [MaxLength];
}


Group::Group(const Group& source)
{
	cout << "Copy constr group" << endl;

	MaxLength = source.MaxLength;
	CurrentLength = 0;

	People = new Person * [MaxLength];

	for (size_t i = 0; i < source.CurrentLength; i++)
	{
		Person* person = new Person(*source.People[i]);
		Add(person);
	}
}


Group::~Group()
{
	cout << "Group destr" << endl;

	// �������� ����� �� ������ �� �������
	for (size_t i = 0; i < CurrentLength; i++)
	{
		delete People[i];
	}

	// �������� ������� ���������� �� �����
	delete[] People;
}


void Group::Add(Person* person)
{
	if (CurrentLength < MaxLength)
	{
		People[CurrentLength++] = person;
	}
	else
	{
		size_t new_lenght = MaxLength + 3;

		cout << "Group resize. New size: " << new_lenght << endl;

		// �������� ������ ��� ����� ������
		Person** new_people = new Person * [new_lenght];

		size_t i = 0;
		// ��������� ���� ����� � �������� �������
		for (; i < CurrentLength; i++)
		{
			// �������� �������� � ����� ������
			new_people[i] = People[i];
		}

		// �������� ������ �������� � ����� ������ �����
		new_people[i] = person;

		// �������� ������� � ������ ������ ��������
		MaxLength = new_lenght;
		CurrentLength++;

		// ������� ������ ������ ����������
		delete[] People;

		// ��������� ����� ������ � ������ � ���� ������ People
		People = new_people;
	}
}


void Group::Print()
{
	for (size_t i = 0; i < CurrentLength; i++) 
	{
		People[i]->Print();
		cout << endl;
	}
}


bool Group::Remove(unsigned index) 
{
	if (index >= 0 && index < CurrentLength) 
	{
		bool is_deleted = false;
		
		for (size_t i = index; i < CurrentLength; i++)
		{
			if (is_deleted == true)
				People[i] = People[i + 1];

			else if (is_deleted == false && i + 1 == CurrentLength)
			{
				delete People[i];
				is_deleted = true;
			}

			else
			{
				delete People[i];
				People[i] = People[i + 1];
				is_deleted = true;
			}
		}

		if (is_deleted == true)
			CurrentLength--;

		return true;
	}
	else
	{
		cout << "There is no such position!!!" << endl;
		return false;
	}
}


bool Group::Remove(Person* person)
{
	bool is_deleted = false;

	for (size_t i = 0; i < CurrentLength; i++)
	{
		if (is_deleted == true)
		{
			People[i] = People[i + 1];
		}
		
		if (*this -> People[i] == *person)
		{
			if (i + 1 == CurrentLength)
			{
				delete People[i];
				is_deleted = true;
			}
			else
			{
				delete People[i];
				People[i] = People[i + 1];
				is_deleted = true;
			}
		}
	}

	if (is_deleted == true)
		CurrentLength--;

	if (is_deleted == true)
		return true;
	else 
		return false;
}


bool Group::Save(const char* file_name) 
{

	FILE* file = fopen(file_name, "w");

	if (file != nullptr)
	{
		char file_text[40];

		_itoa(CurrentLength, file_text, 10);
		fputs(file_text, file);
		fputs("\n", file);

		for (size_t i = 0; i < CurrentLength; i++)
		{
			if (i + 1 == CurrentLength) {
				fprintf(file, "%s %s %d", People[i]->GetFirstName(), People[i]->GetLastName(), *People[i]->GetAge());
				break;
			}

			fprintf(file, "%s %s %d\n", People[i]->GetFirstName(), People[i]->GetLastName(), *People[i]->GetAge());
		}
		fclose(file);
		return true;
	}
	else return false;
}


// D:\test.txt
bool Group::Load(const char* file_name) 
{

	FILE* file = fopen(file_name, "r");

	if (file != nullptr)
	{
		// ��������� CurrentLength c �����
		int old_CurrentLength = CurrentLength;
		int new_CurrentLength = 0;

		int rez = fscanf(file, "%zd", &new_CurrentLength);

		if (new_CurrentLength <= old_CurrentLength)
		{
			CurrentLength = new_CurrentLength;

			for (size_t i = 0; i < CurrentLength; i++)
			{
				int rez2 = fscanf(file, "%s %s %u\n", People[i]->GetFirstName(), People[i]->GetLastName(), People[i]->GetAge());
			}
			fclose(file);
			return true;
		}
		else
		{
			char first_name[200];
			char last_name[200];
			unsigned age = 0;

			CurrentLength = 0;

			for (size_t i = 0; i < new_CurrentLength; i++)
			{
				int rez2 = fscanf(file, "%s %s %u\n", first_name, last_name, &age);
				Person* person = new Person(first_name, last_name, age);
				Add(person);
			}
			fclose(file);
			return true;
		}
	}
	else return false;
}


bool Group::operator == (const Group& group2) 
{

	if (CurrentLength == group2.CurrentLength) {

		for (size_t i = 0; i < CurrentLength; i++)
		{
			if (*this->People[i] != *group2.People[i]) {
				return false;
			}
		}
		return true;
	}
	else
		return false;
}


Group& Group::operator = (const Group& source) 
{

	if (MaxLength != source.MaxLength)
	{
		for (size_t i = 0; i < CurrentLength; i++)
		{
			delete People[i];
		}
		delete[] People;

		MaxLength = source.MaxLength;
		CurrentLength = 0;

		People = new Person * [MaxLength];

		for (size_t i = 0; i < source.CurrentLength; i++)
		{
			Person* person = new Person(*source.People[i]);
			Add(person);
		}
	}
	return *this;
}


Group Group::operator+ (Person* person) 
{
	Group result = *this;
	result.Add(person);
	return result;
}

Group Group::operator- (Person* person)
{
	Group result = *this;
	result.Remove(person);
	return result;
}


Group Group::operator+= (Person* person) 
{
	this->Add(person);
	return *this;
}


Group Group::operator-= (Person* person)
{
	this->Remove(person);
	return *this;
}


Group Group::operator+ (const Group& source) {

	Group result(MaxLength + source.MaxLength);

	result.CurrentLength = 0;
	
	for (size_t i = 0; i < CurrentLength; i++)
	{
		Person* result_person = new Person(*People[i]);
		result.Add(result_person);
	}
	
	for (size_t i = 0; i < source.CurrentLength; i++)
	{
		Person* result_person = new Person(*source.People[i]);
		result.Add(result_person);
	}

	return result;
}