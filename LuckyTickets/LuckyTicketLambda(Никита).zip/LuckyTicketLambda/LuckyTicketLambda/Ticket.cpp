#include <iostream>
#include <vector>
#include "Ticket.h"


Ticket::Ticket()
{
	//std::cout << "Ticket constr" << std::endl;

	TicketNumber = new int[TicketNumberSize];
}


Ticket::Ticket(const int* tick)
{
	//std::cout << "Ticket constr with params" << std::endl;

	TicketNumber = new int[TicketNumberSize];

	for (size_t i = 0; i < TicketNumberSize; i++)
	{
		TicketNumber[i] = tick[i];
	}
}


Ticket::~Ticket()
{
	//std::cout << "Ticket destr" << std::endl;

	delete TicketNumber;
}


size_t Ticket::GetTicketNumberSize()
{
	return TicketNumberSize;
}


int* Ticket::GetTicketNumber()
{
	return TicketNumber;
}


string Ticket::GetCombination()
{
	return Combination;
}


void Ticket::SetCombination(string str)
{
	Combination = str;
}


void Ticket::ShowTicket()
{
	for (size_t i = 0; i < TicketNumberSize; i++)
	{
		std::cout << TicketNumber[i];
	}
	std::cout << std::endl;
}


bool Ticket::IsLucky(std::vector <function<bool(const int*, string&)>> lambdas)
{
	for (auto& function : lambdas)
	{
		if (function(this->TicketNumber, this->Combination))
			return true;
	}

	return false;
}


void Ticket::GenerateNumbers(unsigned ticket_number)
{
	TicketNumber[5] = ticket_number % 10;
	TicketNumber[4] = ticket_number / 10 % 10;
	TicketNumber[3] = ticket_number / 100 % 10;
	TicketNumber[2] = ticket_number / 1000 % 10;
	TicketNumber[1] = ticket_number / 10000 % 10;
	TicketNumber[0] = ticket_number / 100000;
}