#include "Ticket.h"
#include <vector>

#pragma once

class LuckyTickets
{
	std::vector <Ticket*> Tickets;

public:
	LuckyTickets();
	~LuckyTickets();

	void AddLuckyTicket(Ticket* tick);
	void ShowLuckyTickets();
	void Save(string file_name);
};

