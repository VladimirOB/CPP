#pragma once

#include <vector>
#include <string>
#include <functional>

using namespace std;

class Ticket
{
	string Combination;
	int* TicketNumber;

public:

	static const unsigned TicketNumberSize = 6;
	
	Ticket();
	Ticket(const int* tick);
	~Ticket();

	size_t GetTicketNumberSize();
	int* GetTicketNumber();
	string GetCombination();
	void SetCombination(string str);

	void ShowTicket();
	bool IsLucky(std::vector <function<bool(const int*, string&)>> lambdas);
	void GenerateNumbers(unsigned ticket_number);
};

