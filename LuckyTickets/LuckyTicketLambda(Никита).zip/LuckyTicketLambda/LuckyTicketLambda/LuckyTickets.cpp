#include "LuckyTickets.h"
#include <iostream>
#include <fstream>

using namespace std;

LuckyTickets::LuckyTickets()
{
	//cout << "LuckyTickets constr" << endl;
	Tickets.reserve(1000);
}


LuckyTickets::~LuckyTickets()
{
	//cout << "LuckyTickets destr" << endl;

	for (size_t i = 0; i < Tickets.size(); i++)
	{
		delete Tickets[i];
	}
}


void LuckyTickets::AddLuckyTicket(Ticket* tick)
{
	Tickets.push_back(tick);
}


void LuckyTickets::ShowLuckyTickets()
{
	cout << "Lucky tickets: " << endl;
	
	for (size_t i = 0; i < Tickets.size(); i++)
	{
		Tickets[i]->ShowTicket();
	}
}

void LuckyTickets::Save(string file_name)
{
	ofstream file(file_name);

	if (!file.fail())
	{
		file << "Quantity: " << Tickets.size() << endl;
		
		for (size_t i = 0; i < Tickets.size(); i++)
		{
			for (size_t j = 0; j < Tickets[i]->GetTicketNumberSize(); j++)
			{
				file << Tickets[i]->GetTicketNumber()[j];
			}
			file << " - " << Tickets[i]->GetCombination() << endl;
		}

		file.close();
	}
	else cout << "Error opening file!" << endl;
}